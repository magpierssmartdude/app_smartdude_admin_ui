import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AddService } from '../service/add-service.service';
import { first } from 'rxjs/operators';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-service',
  templateUrl: './add-service.component.html',
  styleUrls: ['./add-service.component.css']
})
export class AddServiceComponent implements OnInit {

  constructor(private formBuilder: FormBuilder, private router: Router, private addService: AddService) { }

  addServiceForm: FormGroup;
  submitted: boolean;

  ngOnInit() {

    this.addServiceForm = this.formBuilder.group({
      serviceid: [],
      queuename: ['', Validators.required],
      servicename: ['', Validators.required],
      price: ['', Validators.required],
      units: ['', Validators.required],
      noofserves: ['', Validators.required]
    });

  }

  onSubmit() {
    const createServiceRequest = {
      serviceid: parseInt(this.addServiceForm.controls.serviceid.value, 0),
      queue: {
        queuename: this.addServiceForm.controls.queuename.value,
      },
      servicename: this.addServiceForm.controls.servicename.value,
      price: parseInt(this.addServiceForm.controls.price.value, 0),
      noofserves: parseInt(this.addServiceForm.controls.noofserves.value, 0)
    }
    this.addService.createService(createServiceRequest)
      .subscribe(data => {
        this.router.navigate(['list-user']);
      });
      this.submitted = true;
  }

}
