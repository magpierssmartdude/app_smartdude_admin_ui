import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpClientModule } from '@angular/common/http';
import { User } from '../../model/user.model';

@Injectable()
export class CreateQueuesService {
  constructor(private http: HttpClient) { }
  baseUrl = '/swagger/';

  getVendorList() {
    return this.http.get<any>(`${this.baseUrl}admin/findallvendors`);
  }

  editLocation(locationId: any, data: any) {
    return this.http.put(this.baseUrl + '/vendor/updatelocation/' + locationId, data);
  }

  getUserById(id: number) {
    return this.http.get<User>(this.baseUrl + '/' + id);
  }

  getLocationDetail(vendorId: number, locationId: number) {
    return this.http.get<User>(this.baseUrl + 'vendor/' + vendorId + '/locations/' + locationId);
  }

  deleteLocationDetail(vendorId: number, locationId: number) {
    return this.http.delete<User>(this.baseUrl + 'vendor/' + vendorId + '/deletelocation/' + locationId);
  }

  getQueueList(id: number) {
    return this.http.get<User>(this.baseUrl + 'qm/' + id + '/queue');
  }

  createQueue(data: any) {
    console.log(data);
    return this.http.post(this.baseUrl + '/qm/queue', data);
  }

  updateUser(user: User) {
    return this.http.put(this.baseUrl + '/' + user.id, user);
  }

  deleteUser(id: number) {
    return this.http.delete(this.baseUrl + '/' + id);
  }
}
