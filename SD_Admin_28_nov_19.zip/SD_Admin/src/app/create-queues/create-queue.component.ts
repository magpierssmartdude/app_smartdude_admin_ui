import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { takeWhile } from 'rxjs/operators';
import { MessageService } from 'primeng/api';
import { HttpErrorResponse } from '@angular/common/http';
import { CreateQueuesService } from "./service/create-queues.service";
import { first } from "rxjs/operators";
import { Router } from "@angular/router";

@Component({
  selector: 'app-create-queue',
  templateUrl: './create-queue.component.html',
  styleUrls: ['./create-queue.component.css'],
  providers: [CreateQueuesService, MessageService]
})
export class CreateQueueComponent implements OnInit {

  constructor(private formBuilder: FormBuilder, private messageService: MessageService,
    private router: Router, private createQueueService: CreateQueuesService) { }

  queueList: any;
  addQueueForm: FormGroup;
  submitted: boolean;
  subscriberFlag = true;
  qmanagerList = [];
  editFlag = false;
  queueManagerId: any;
  editLocationId: any;
  showLoader: boolean;

  saveLocationRequest = {};

  ngOnInit() {
    this.getQueueList();
    this.addQueueForm = this.formBuilder.group({
      queuename: ['', Validators.required]
    });    
  }

  // onSubmit() {
  //   this.addService.createUser(this.addQueueForm.value)
  //     .subscribe(data => {
  //       this.router.navigate(['list-user']);
  //     });
  //   this.submitted = true;
  // }

  onSubmit() {
    if (this.addQueueForm.valid) {
      this.saveLocationRequest = {
        queuename: this.addQueueForm.controls['queuename'].value,
        locationQueueManagerAssociation: {
          locqmanagerassociationid: 10
        }
      };

      // for (const key in this.addQueueForm.value) {
      //   if (this.addQueueForm.value.hasOwnProperty(key)) {
      //     if(key === 'queuestarttime'){
      //       for (const subkey in key) {
      //         if (this.addQueueForm.value.hasOwnProperty(subkey)) {
      //           this.saveLocationRequest[subkey] = this.addQueueForm.value[subkey];
      //         }
      //       }
      //     }
      //     console.log(key, this.saveLocationRequest[key]);
      //     this.saveLocationRequest[key] = this.addQueueForm.value[key];
      //   }
      // }
      console.log(this.saveLocationRequest);
      this.createQueueService.createQueue(this.saveLocationRequest)
          .subscribe(data => {
            if (data) {
              this.showAddMessage();
              // this.getQmanagerList();
            }
          });
      // if (this.editFlag) {
      //   this.saveLocationRequest['queuemanagerid'] = this.queueManagerId;
      //   this.createQueueService.editQueueManagerDetails(this.queueManagerId, this.saveLocationRequest)
      //     .subscribe(data => {
      //       if (data) {
      //         this.showEditMessage();
      //         // this.getQmanagerList();
      //         this.showLoader = true;
      //       }
      //     });
      //   this.editFlag = false;
      // } else {
      //   this.createQueueService.createQueue(this.saveLocationRequest)
      //     .subscribe(data => {
      //       if (data) {
      //         this.showAddMessage();
      //         // this.getQmanagerList();
      //       }
      //     });
      // }
      this.addQueueForm.reset();
      this.showLoader = false;
      this.submitted = false;
    } else {
      this.submitted = true;
    }
  }

  showDeleteMessage() {
    this.messageService.add({ sticky: true, severity: 'success', summary: 'Success message', detail: 'Successfully deleted' });
  }
  showEditMessage() {
    this.messageService.add({ sticky: true, severity: 'success', summary: 'Success message', detail: 'Successfully edited location' });
  }

  showAddMessage() {
    this.messageService.add({ sticky: true, severity: 'success', summary: 'Success message', detail: 'Successfully added location' });
  }

  getQueueList() {
    this.showLoader = true;
    this.createQueueService.getQueueList(10)
      .pipe(takeWhile(() => this.subscriberFlag))
      .subscribe((response: any) => {
        this.queueList = response;
        this.showLoader = false;
        console.log('vendor list' + response);

      }, (error: HttpErrorResponse) => {
        console.log(error);
      });

  }

  resetForm() {
    this.addQueueForm.reset();
  }

}
