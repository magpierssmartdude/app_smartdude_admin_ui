// Section 1
import { Injectable } from '@angular/core'
import { Action } from '@ngrx/store'
import { Location } from '../model/location.model'

// Section 2
export const ADD_LOCATION       = '[LOCATION] Add'
export const DELETE_LOCATION    = '[LOCATION] Remove'

// Section 3
export class AddLocation implements Action {
    readonly type = ADD_LOCATION

    constructor(public payload: Location) {}
}

export class DeleteLocation implements Action {
    readonly type = DELETE_LOCATION

    constructor(public payload: number) {}
}

// Section 4
export type Actions = AddLocation | DeleteLocation