
import { Action } from '@ngrx/store'
import { AddLocation } from '../actions/add-location.actions'
import * as LocationAction from './../actions/add-location.actions';
import {Location} from '../model/location.model';


// Section 1
const initialState: Location = {
    area : 'test',
    block: 'test',
    building: 'test',
    city: 'test',
    floor: 'test',
    landmark: 'test',
    locationid: 0,
    state: 'test',
    vendor: {    
      status: true,
      vendorcode: 'test',
      vendorid: 1,
      vendorname: 'test'
    }
}

// Section 2
export function reducer(state: Location[] = [initialState], action: LocationAction.Actions) {

    // Section 3
    switch(action.type) {
        case LocationAction.ADD_LOCATION:
            return [...state, action.payload];
        default:
            return state;
    }
}