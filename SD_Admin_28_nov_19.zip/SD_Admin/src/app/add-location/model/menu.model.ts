export class MainMenuItem {
  label: string;
  icon: string;
  routerLink: string[];
}

export class MenuItem {
  label: string;
  icon: string;
  routerLink: string[];
}


