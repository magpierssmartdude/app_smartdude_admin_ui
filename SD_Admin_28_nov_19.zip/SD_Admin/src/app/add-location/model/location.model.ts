export class Location {
    area: string;
    block: string;
    building: string;
    city: string;
    floor: string;
    landmark: string;
    locationid: 0;
    state: string;
    vendor: {    
      status: boolean;
      vendorcode: string;
      vendorid: number;
      vendorname: string
    }
  }