import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { PanelModule } from 'primeng/panel';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DropdownModule } from 'primeng/dropdown';

import { OrderListModule } from 'primeng/orderlist';
import { TableModule } from 'primeng/table';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { ToastModule } from 'primeng/toast';
import { RadioButtonModule } from 'primeng/radiobutton';
import { CardModule } from 'primeng/card';
import { PaginatorModule } from 'primeng/paginator';
import { FileUploadModule } from 'primeng/fileupload';
import { AddLocationComponent } from './add-location.component';
@NgModule({
    imports: [
        CommonModule,
        PanelModule,
        FormsModule,
        ReactiveFormsModule,
        RadioButtonModule,
        FileUploadModule,
        TableModule,
        CardModule,
        ToastModule,
        ProgressSpinnerModule,
        PaginatorModule
    ],
    declarations: [AddLocationComponent],
    providers: [DatePipe]
})

export class AddLocationModule {

    constructor() {
    }

}
