import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { LoginComponent } from './login/login.component';
import { AddLocationComponent } from './add-location/add-location.component';
import { AddServiceComponent } from './add-service/add-service.component';
import { ListUserComponent } from './list-user/list-user.component';
import { CreateQueueComponent } from './create-queues/create-queue.component';
import { CreateAdminComponent } from './create-admin/create-admin.component';
import { VendorListComponent } from './vendor-list/vendor-list.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HomeComponent } from './home/home.component';
import { AddVendorDetailsComponent } from './add-vendor-details/add-vendor-details.component';
import { SignupComponent } from './signup/signup.component';
import { SignUpRequestsComponent } from './sign-up-requests/sign-up-requests.component';
import { AddQueueManagerComponent } from './add-queue-manager/add-queue-manager.component';
import { CreateAccountComponent } from './create-account/create-account.component';
import { QueueDetailsComponent } from './queue-details/queue-details.component';
import { AssociateLocationQManagerComponent } from './associate_location_qmanager/associate-location-qmanager.component';
import { SearchQueueComponent } from './search-queue/search-queue.component';
import { ServiceDetailsComponent } from './service-details/service-details.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'home', component: HomeComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'add-location', component: AddLocationComponent },
  { path: 'create-account', component: CreateAccountComponent },
  { path: 'queue-details', component: QueueDetailsComponent },
  { path: 'service-details', component: ServiceDetailsComponent },
  { path: 'search-queue', component: SearchQueueComponent },
  { path: 'add-queue-manager', component: AddQueueManagerComponent },
  { path: 'associate-location-qmanager', component: AssociateLocationQManagerComponent },
  { path: 'create-admin', component: CreateAdminComponent },
  { path: 'list-user', component: ListUserComponent },
  { path: 'create-queue', component: CreateQueueComponent },
  { path: 'add-service', component: AddServiceComponent },
  { path: 'vendor-list', component: VendorListComponent },
  { path: 'add-vendor-details', component: AddVendorDetailsComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'SignUpRequests', component: SignUpRequestsComponent },
  { path: '', component: LoginComponent },
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
