import { Component, OnInit, ElementRef, HostListener, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { MenuItem } from 'primeng/api';
import { MainMenuItem } from './model/menu.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})


export class AppComponent implements OnInit {
  title = 'SmartDude';
  display = true;
  locked = false;
  showMenu = true;
  menuItems: MainMenuItem[];
  items: MenuItem[];


  constructor(private route: ActivatedRoute, private router: Router, private eRef: ElementRef,
    private titleService: Title) { }

  @HostListener('document:click', ['$event'])
  clickout(event) {
    if (event.target.id.toLowerCase() === 'leftmenu') {
      this.display = true;
    } else {
      this.display = false;
    }
  }


  ngOnInit() {
    this.display = false;
    this.setDocTitle(this.title);
    this.items = [
      { label: 'New', icon: 'pi pi-fw pi-plus' },
      { label: 'Open', icon: 'pi pi-fw pi-download' },
      { label: 'Undo', icon: 'pi pi-fw pi-refresh' }
    ];
    this.menuItems = [
      {
        label: 'Home', icon: 'fa fa-fw fa-home', routerLink: ['/home']
      },
      {
        label: 'Add Location', icon: 'fa fa-fw fa-map-marker', routerLink: ['/add-location']
      },
      {
        label: 'Add Queue Manager', icon: 'fa fa-fw fa-user', routerLink: ['/add-queue-manager']
      },
      {
        label: 'Create Queue', icon: 'fa fa-fw fa-group', routerLink: ['/create-queue']
      },
      {
        label: 'Add Service', icon: 'fa fa-fw fa-gears', routerLink: ['/add-service']
      },
      {
        label: 'Vendor SignUp', icon: 'fa fa-fw fa-cubes', routerLink: ['/add-vendor-details']
      },
      {
        label: 'Create Admin', icon: 'fa fa-fw fa-user-circle', routerLink: ['/create-admin']
      }
    ];
  }

  setDocTitle(title: string) {
    console.log('current title:::::' + this.titleService.getTitle());
    this.titleService.setTitle(title);
  }

  toggleMenu(event) {
    this.display = !this.display;
  }

  lockMenu(event) {
    this.locked = !this.locked;
  }

  menuToggle(event) {
    this.showMenu = !this.showMenu;
  }

  navigateToSignUp(event) {
    this.router.navigate(['/add-vendor-details']);
  }

  navigateToServiceDetails(event) {
    this.router.navigate(['/service-details']);
  }

  navigateToSearchQueue(event) {
    this.router.navigate(['/search-queue']);
  }


  logout() {
    this.router.navigate(['/login/'], { relativeTo: this.route });
  }
}
