import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssociateLocationQManagerComponent } from './associate-location-qmanager.component';

describe('AddUserComponent', () => {
  let component: AssociateLocationQManagerComponent;
  let fixture: ComponentFixture<AssociateLocationQManagerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AssociateLocationQManagerComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssociateLocationQManagerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
