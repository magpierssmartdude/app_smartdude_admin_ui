import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { MegaMenuModule } from 'primeng/megamenu';
import { ReactiveFormsModule } from "@angular/forms";
import { PanelModule } from 'primeng/panel';
import { ChartModule } from 'primeng/chart';
import { CardModule } from 'primeng/card';
import { QueueDetailsComponent } from './queue-details.component';
@NgModule({
    imports: [
        CommonModule,
        MegaMenuModule,
        PanelModule,
        ChartModule,
        CardModule,
        ReactiveFormsModule
    ],
    declarations: [QueueDetailsComponent],
    providers: [DatePipe]
})

export class QueueDetailsModule {

    constructor() {
    }

}
