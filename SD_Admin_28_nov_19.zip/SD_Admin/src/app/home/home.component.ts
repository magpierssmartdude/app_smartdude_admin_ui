import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { first } from 'rxjs/operators';
import { takeWhile } from 'rxjs/operators';
import { Router } from '@angular/router';
import { VendorService } from './service/home-vendor.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers: [VendorService]
})
export class HomeComponent implements OnInit, OnDestroy {
  subscriberFlag = true;
  constructor(private formBuilder: FormBuilder, private router: Router, private vendorService: VendorService) { }

  addLocationForm: FormGroup;
  submitted: boolean;
  vendorList: [];
  cols: any[];
  totalVendorList: any;
  showLoader: boolean;

  ngOnInit() {
    this.addLocationForm = this.formBuilder.group({
      location: ['', Validators.required],
      pincode: ['', Validators.required],
      landmark: ['', Validators.required],
      floor: ['', Validators.required],
      block: ['', Validators.required],
      building: ['', Validators.required]
    });

    this.getVendorList();
    // Object.keys(this.vendorList).forEach(item => {
    //   console.log(item)
    //   this.cols.push({ field: item, field: item });
    // });
  }

  ngOnDestroy() {
    this.subscriberFlag = false;
  }

  getVendorList() {
    this.showLoader = false;
    this.vendorService.getVendorList()
      .pipe(takeWhile(() => this.subscriberFlag))
      .subscribe((response: any) => {
        this.vendorList = response;
        console.log('vendor list' + response);
        this.totalVendorList = this.vendorList.length;
        this.showLoader = true;
      }, (error: HttpErrorResponse) => {
        console.log(error);
      });
  }

  onSubmit() {
    this.vendorService.createUser(this.addLocationForm.value)
      .subscribe(data => {
        this.router.navigate(['list-user']);
      });
    this.submitted = true;
  }

}
