import { FormGroup } from '@angular/forms';

export class SignUpModel {
    signupForm: FormGroup;
    subscriberFlag: boolean;
    checkBoxValue: boolean;
    signUpClicked: boolean;
    constructor() {
        this.subscriberFlag = true;
        this.checkBoxValue = false;
        this.signUpClicked = false;
    }
}