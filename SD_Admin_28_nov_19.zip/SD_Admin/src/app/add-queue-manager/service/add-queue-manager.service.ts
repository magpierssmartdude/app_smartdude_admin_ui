import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpClientModule } from '@angular/common/http';
import { User } from '../../model/user.model';

@Injectable()
export class AddQueueManagerService {
  constructor(private http: HttpClient) { }
  baseUrl = '/swagger/';

  getVendorList() {
    return this.http.get<any>(`${this.baseUrl}admin/findallvendors`);
  }

  editQueueManagerDetails(locationId: any, data: any) {
    return this.http.put(this.baseUrl + '/vendor/qmanager/' + locationId, data);
  }

  getUserById(id: number) {
    return this.http.get<User>(this.baseUrl + '/' + id);
  }

  getQueueManagerDetail(vendorId: number, queueManagerId: number) {
    return this.http.get<User>(this.baseUrl + 'vendor/' + vendorId + '/qmanagers/' + queueManagerId);
  }

  deleteLocationDetail(vendorId: number, queueManagerId: number) {
    return this.http.delete<User>(this.baseUrl + 'vendor/' + vendorId + '/deletelocation/' + queueManagerId);
  }

  getQueueManagerList(id: number) {
    return this.http.get<User>(this.baseUrl + 'vendor/' + id + '/qmanagers');
  }

  createQueueManager(data: any) {
    console.log(data);
    return this.http.post(this.baseUrl + 'vendor/qmanager', data);
  }

  updateUser(user: User) {
    return this.http.put(this.baseUrl + '/' + user.id, user);
  }

  deleteUser(id: number) {
    return this.http.delete(this.baseUrl + '/' + id);
  }
}
