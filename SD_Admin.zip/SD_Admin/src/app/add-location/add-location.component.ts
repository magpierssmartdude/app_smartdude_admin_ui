import { Component, OnInit, OnDestroy } from '@angular/core';
import { takeWhile } from 'rxjs/operators';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { HttpErrorResponse } from '@angular/common/http';
import { AddLocationService } from './service/add-location.service';
import { first } from 'rxjs/operators';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-location',
  templateUrl: './add-location.component.html',
  styleUrls: ['./add-location.component.css'],
  providers: [AddLocationService, MessageService]
})
export class AddLocationComponent implements OnInit, OnDestroy {

  constructor(private formBuilder: FormBuilder, private router: Router, private addService: AddLocationService,
    private messageService: MessageService) { }

  addLocationForm: FormGroup;
  submitted: boolean;
  subscriberFlag = true;
  locationList = [];
  editFlag = false;
  locationId: any;
  editLocationId: any;
  showLoader: boolean;
  patchObject = {
    landmark: '',
    city: '',
    state: '',
    area: '',
    floor: '',
    block: '',
    building: ''
  };

saveLocationRequest = {
  "area": "string",
  "block": "string",
  "building": "string",
  "city": "string",
  "floor": "string",
  "landmark": "string",
  "locationid": 0,
  "state": "string",
  "vendor": {    
    "status": false,
    "vendorcode": "ISS",
    "vendorid": 1,
    "vendorname": "Anamika"
  }
};

  saveLocationRequest1 = {
    'area': '',
    'block': '',
    'building': '',
    'city': '',
    'floor': '',
    'landmark': '',
    'state': '',
    'locationid': 0,
    'vendor': {
      'vendorid': 9
    }



    // 'state': 'TN',
    // 'city': 'chennai',
    // 'area': 'Siruseri',
    // 'landmark': 'CTS',
    // 'building': '123',
    // 'floor': '1',
    // 'block': 'B',
    // 'vendor': {
    //   'vendorid': 9
    // },
    // 'activestatus': 1

  };

  ngOnInit() {
    this.getLocationList();
    this.addLocationForm = this.formBuilder.group({
      // location: ['', Validators.required],
      landmark: ['', Validators.required],
      city: ['', Validators.required],
      state: ['', Validators.required],
      area: ['', Validators.required],
      floor: ['', Validators.required],
      block: ['', Validators.required],
      building: ['', Validators.required]
    });
    this.showLoader = false;
  }

  ngOnDestroy() {
    this.subscriberFlag = false;
  }

  showDeleteMessage() {
    this.messageService.add({ sticky: true, severity: 'success', summary: 'Success message', detail: 'Successfully deleted' });
  }
  showEditMessage() {
    this.messageService.add({ sticky: true, severity: 'success', summary: 'Success message', detail: 'Successfully edited location' });
  }

  showAddMessage() {
    this.messageService.add({ sticky: true, severity: 'success', summary: 'Success message', detail: 'Successfully added location' });
  }

  onSubmit() {
    for (const key in this.addLocationForm.value) {
      if (this.addLocationForm.value.hasOwnProperty(key)) {
        console.log(key, this.saveLocationRequest[key]);
        if (key === 'vendor') {
          this.saveLocationRequest[key]['vendorid'] = this.addLocationForm.value[key];
        } else {
          this.saveLocationRequest[key] = this.addLocationForm.value[key];
        }
      }
    }
    console.log(this.saveLocationRequest);
    if (this.editFlag) {
      this.addService.editLocation(this.editLocationId, this.saveLocationRequest)
        .subscribe(data => {
          if (data) {
            this.showEditMessage();
            this.getLocationList();
            this.showLoader = true;
          }
        });
      this.editFlag = false;
    } else {
      this.addService.createLocation(this.saveLocationRequest)
        .subscribe(data => {
          if (data) {
            this.showAddMessage();
            this.getLocationList();
          }
        });
    }
    this.addLocationForm.reset();
    this.submitted = true;
    this.showLoader = false;
  }

  getLocationList() {
    this.showLoader = true;
    this.addService.getLocationList(1)
      .pipe(takeWhile(() => this.subscriberFlag))
      .subscribe((response: any) => {
        this.locationList = response;
        this.showLoader = false;
        console.log('vendor list' + response);

      }, (error: HttpErrorResponse) => {
        console.log(error);
      });

  }

  getEditLocationDetail(locationId) {
    console.log(locationId);
    this.editFlag = true;
    this.showLoader = true;
    this.addService.getLocationDetail(1, locationId)
      .pipe(takeWhile(() => this.subscriberFlag))
      .subscribe((response: any) => {
        console.log(response);
        this.editLocationId = response.locationid;
        this.patchData(response);
        this.showLoader = false;
      }, (error: HttpErrorResponse) => {
        console.log(error);
      });

  }

  deleteLocation(locationId) {
    this.showLoader = true;
    this.addService.deleteLocationDetail(1, locationId)
      .subscribe(data => {
        this.showDeleteMessage();
        this.getLocationList();
        this.showLoader = false;
      });
  }

  patchData(response: any) {
    for (const key in this.patchObject) {
      if (this.patchObject.hasOwnProperty(key)) {
        this.addLocationForm.controls[key].setValue(response[key]);
      }
    }
  }

}
