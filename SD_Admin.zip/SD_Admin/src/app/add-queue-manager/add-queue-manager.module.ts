import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { PanelModule } from 'primeng/panel';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DropdownModule } from 'primeng/dropdown';

import { OrderListModule } from 'primeng/orderlist';
import { TableModule } from 'primeng/table';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { ToastModule } from 'primeng/toast';
import { RadioButtonModule } from 'primeng/radiobutton';
import { CardModule } from 'primeng/card';
import { PaginatorModule } from 'primeng/paginator';
import { FileUploadModule } from 'primeng/fileupload';
import { AddQueueManagerComponent } from './add-queue-manager.component';
@NgModule({
  declarations: [AddQueueManagerComponent],
  imports: [
    CommonModule,
    PanelModule,
    FormsModule,
    ReactiveFormsModule,
    RadioButtonModule,
    FileUploadModule,
    TableModule,
    CardModule,
    ToastModule,
    ProgressSpinnerModule,
    PaginatorModule
  ]
})
export class AddQueueManagerModule { }
