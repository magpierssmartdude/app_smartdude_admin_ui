import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sign-up-requests',
  templateUrl: './sign-up-requests.component.html',
  styleUrls: ['./sign-up-requests.component.css']
})
export class SignUpRequestsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
