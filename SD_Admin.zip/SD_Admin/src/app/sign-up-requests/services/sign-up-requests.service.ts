import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders, HttpClientModule } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})

export class SignUpRequestsService {
    constructor(private readonly http: HttpClient) { }

}