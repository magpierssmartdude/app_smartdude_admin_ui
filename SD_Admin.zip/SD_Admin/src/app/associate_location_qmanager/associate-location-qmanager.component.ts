import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { MessageService } from 'primeng/api';
import { HttpErrorResponse } from '@angular/common/http';
import { AssociateLocationQManagerService } from "./service/associate-location-qmanager.service";
import { first } from "rxjs/operators";
import { Router } from "@angular/router";

@Component({
  selector: 'app-associate-location-qmanager',
  templateUrl: './associate-location-qmanager.component.html',
  styleUrls: ['./associate-location-qmanager.component.css'],
  providers: [AssociateLocationQManagerService, MessageService]
})
export class AssociateLocationQManagerComponent implements OnInit {

  constructor(private formBuilder: FormBuilder, private messageService: MessageService,
    private router: Router, private createQueueService: AssociateLocationQManagerService) { }


  addQueueForm: FormGroup;
  submitted: boolean;
  subscriberFlag = true;
  qmanagerList = [];
  editFlag = false;
  queueManagerId: any;
  editLocationId: any;
  showLoader: boolean;

  saveLocationRequest = {
    activestatus: 1,
    qmanagerid: 4,
    locationid: 5,
    vendor:{
      vendorid: 13
    }
  };

  ngOnInit() {
    this.addQueueForm = this.formBuilder.group({
      qManagerId: ['', Validators.required],
      locationId: ['', Validators.required]
    });
  }

  // onSubmit() {
  //   this.addService.createUser(this.addQueueForm.value)
  //     .subscribe(data => {
  //       this.router.navigate(['list-user']);
  //     });
  //   this.submitted = true;
  // }

  onSubmit() {
    if (this.addQueueForm.valid) {

      // for (const key in this.addQueueForm.value) {
      //   if (this.addQueueForm.value.hasOwnProperty(key)) {
      //     console.log(key, this.saveLocationRequest[key]);
      //     this.saveLocationRequest[key] = this.addQueueForm.value[key];
      //   }
      // }
      console.log(this.saveLocationRequest);
      this.createQueueService.createQManagerAssociation(this.saveLocationRequest, 13)
          .subscribe(data => {
            if (data) {
              this.showAddMessage();
              // this.getQmanagerList();
            }
          });
      // if (this.editFlag) {
      //   this.saveLocationRequest['queuemanagerid'] = this.queueManagerId;
      //   this.createQueueService.editQueueManagerDetails(this.queueManagerId, this.saveLocationRequest)
      //     .subscribe(data => {
      //       if (data) {
      //         this.showEditMessage();
      //         // this.getQmanagerList();
      //         this.showLoader = true;
      //       }
      //     });
      //   this.editFlag = false;
      // } else {
      //   this.createQueueService.createQueue(this.saveLocationRequest)
      //     .subscribe(data => {
      //       if (data) {
      //         this.showAddMessage();
      //         // this.getQmanagerList();
      //       }
      //     });
      // }
      this.addQueueForm.reset();
      this.showLoader = false;
      this.submitted = false;
    } else {
      this.submitted = true;
    }
  }

  showDeleteMessage() {
    this.messageService.add({ sticky: true, severity: 'success', summary: 'Success message', detail: 'Successfully deleted' });
  }
  showEditMessage() {
    this.messageService.add({ sticky: true, severity: 'success', summary: 'Success message', detail: 'Successfully edited location' });
  }

  showAddMessage() {
    this.messageService.add({ sticky: true, severity: 'success', summary: 'Success message', detail: 'Successfully added location' });
  }

  resetForm() {
    this.addQueueForm.reset();
  }

}
