import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpClientModule } from '@angular/common/http';
import { User } from '../../model/user.model';

@Injectable()
export class AssociateLocationQManagerService {
  constructor(private http: HttpClient) { }
  baseUrl = '/swagger/';

  getVendorList() {
    return this.http.get<any>(`${this.baseUrl}admin/findallvendors`);
  }

  editLocation(locationId: any, data: any) {
    return this.http.put(this.baseUrl + '/vendor/updatelocation/' + locationId, data);
  }

  getUserById(id: number) {
    return this.http.get<User>(this.baseUrl + '/' + id);
  }

  getLocationDetail(vendorId: number, locationId: number) {
    return this.http.get<User>(this.baseUrl + 'vendor/' + vendorId + '/locations/' + locationId);
  }

  deleteLocationDetail(vendorId: number, locationId: number) {
    return this.http.delete<User>(this.baseUrl + 'vendor/' + vendorId + '/deletelocation/' + locationId);
  }

  getLocationList(id: number) {
    return this.http.get<User>(this.baseUrl + 'vendor/' + id + '/locations');
  }

  createQManagerAssociation(data: any, vendorId) {
    console.log(data);
    return this.http.post(this.baseUrl + '/vendor/' + vendorId + '/associatelocationqmanager', data);
  }

  updateUser(user: User) {
    return this.http.put(this.baseUrl + '/' + user.id, user);
  }

  deleteUser(id: number) {
    return this.http.delete(this.baseUrl + '/' + id);
  }
}
