import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { MessageService } from 'primeng/api';
import { HttpErrorResponse } from '@angular/common/http';
import { CreateQueuesService } from "./service/create-queues.service";
import { first } from "rxjs/operators";
import { Router } from "@angular/router";

@Component({
  selector: 'app-create-queue',
  templateUrl: './create-queue.component.html',
  styleUrls: ['./create-queue.component.css'],
  providers: [CreateQueuesService, MessageService]
})
export class CreateQueueComponent implements OnInit {

  constructor(private formBuilder: FormBuilder, private messageService: MessageService,
    private router: Router, private createQueueService: CreateQueuesService) { }


  addQueueForm: FormGroup;
  submitted: boolean;
  subscriberFlag = true;
  qmanagerList = [];
  editFlag = false;
  queueManagerId: any;
  editLocationId: any;
  showLoader: boolean;

  saveLocationRequest = {
    queuename:'queue1',
    locationQueueManagerAssociation: {
      locqmanagerassociationid: 5
    }
  };

  ngOnInit() {
    this.addQueueForm = this.formBuilder.group({
      queuename: ['', Validators.required],
      mobile: ['', Validators.required],
      email: ['', Validators.required],
      location: ['', Validators.required]
    });
  }

  // onSubmit() {
  //   this.addService.createUser(this.addQueueForm.value)
  //     .subscribe(data => {
  //       this.router.navigate(['list-user']);
  //     });
  //   this.submitted = true;
  // }

  onSubmit() {
    if (this.addQueueForm.valid) {

      // for (const key in this.addQueueForm.value) {
      //   if (this.addQueueForm.value.hasOwnProperty(key)) {
      //     console.log(key, this.saveLocationRequest[key]);
      //     this.saveLocationRequest[key] = this.addQueueForm.value[key];
      //   }
      // }
      console.log(this.saveLocationRequest);
      this.createQueueService.createQueue(this.saveLocationRequest)
          .subscribe(data => {
            if (data) {
              this.showAddMessage();
              // this.getQmanagerList();
            }
          });
      // if (this.editFlag) {
      //   this.saveLocationRequest['queuemanagerid'] = this.queueManagerId;
      //   this.createQueueService.editQueueManagerDetails(this.queueManagerId, this.saveLocationRequest)
      //     .subscribe(data => {
      //       if (data) {
      //         this.showEditMessage();
      //         // this.getQmanagerList();
      //         this.showLoader = true;
      //       }
      //     });
      //   this.editFlag = false;
      // } else {
      //   this.createQueueService.createQueue(this.saveLocationRequest)
      //     .subscribe(data => {
      //       if (data) {
      //         this.showAddMessage();
      //         // this.getQmanagerList();
      //       }
      //     });
      // }
      this.addQueueForm.reset();
      this.showLoader = false;
      this.submitted = false;
    } else {
      this.submitted = true;
    }
  }

  showDeleteMessage() {
    this.messageService.add({ sticky: true, severity: 'success', summary: 'Success message', detail: 'Successfully deleted' });
  }
  showEditMessage() {
    this.messageService.add({ sticky: true, severity: 'success', summary: 'Success message', detail: 'Successfully edited location' });
  }

  showAddMessage() {
    this.messageService.add({ sticky: true, severity: 'success', summary: 'Success message', detail: 'Successfully added location' });
  }

  resetForm() {
    this.addQueueForm.reset();
  }

}
