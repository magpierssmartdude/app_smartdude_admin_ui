import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { PanelModule } from 'primeng/panel';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DropdownModule } from 'primeng/dropdown';
import { RadioButtonModule } from 'primeng/radiobutton';
import { CardModule } from 'primeng/card';
import { PaginatorModule } from 'primeng/paginator';
import { FileUploadModule } from 'primeng/fileupload';
import { OrderListModule } from 'primeng/orderlist';
import { TableModule } from 'primeng/table';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { VendorService } from './service/home-vendor.service';
import { HomeComponent } from './home.component';
@NgModule({
    imports: [
        CommonModule,
        PanelModule,
        FormsModule,
        ReactiveFormsModule,
        RadioButtonModule,
        FileUploadModule,
        OrderListModule,
        CardModule,
        ProgressSpinnerModule,
        TableModule,
        PaginatorModule
    ],
    declarations: [HomeComponent],
    providers: [DatePipe]
})

export class HomeModule {

    constructor() {
    }

}
