import { Component, OnInit, OnDestroy } from '@angular/core';
import { takeWhile } from 'rxjs/operators';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MessageService } from 'primeng/api';
import { HttpErrorResponse } from '@angular/common/http';
import { AddQueueManagerService } from './service/add-queue-manager.service';
import { first } from 'rxjs/operators';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-queue-manager',
  templateUrl: './add-queue-manager.component.html',
  styleUrls: ['./add-queue-manager.component.css'],
  providers: [AddQueueManagerService, MessageService]
})
export class AddQueueManagerComponent implements OnInit, OnDestroy {
  addQueueForm: FormGroup;
  submitted: boolean;
  subscriberFlag = true;
  qmanagerList = [];
  editFlag = false;
  queueManagerId: any;
  editLocationId: any;
  showLoader: boolean;
  patchObject = {
    queuemanagername: '',
    qmanagerphonenumber: '',
    qmanageremailId: ''
  };

saveLocationRequest = {
  "activestatus": true,
  "createdtimestamp": "2019-11-19T12:57:46.442Z",
  "qmanageremailId": "string",
  "qmanagerpassword": "string",
  "qmanagerphonenumber": "string",
  "queuemanagerid": 0,
  "queuemanagername": "string",
  "updatedtimestamp": "2019-11-19T12:57:46.442Z",
  "vendor": {  
    "organizationname": "ISS Food Chain",
    "organizationtype": "Cafeteria",
    "password": "string",
    "phonenumber": 9999999999,
    "queuemanagers": [
      null
    ],
    "status": false,
    "vendorcode": "ISS",
    "vendorid": 1,
    "vendorname": "Anamika"
  }
};

  // saveLocationRequest = {
  //   'queuemanagername': '',
  //   'qmanagerphonenumber': '',
  //   'qmanageremailId': '',
  //   'queuemanagerid': 0,
  //   'vendor': {
  //     'vendorid': 9,
  //     'status': true
  //   },
  //   'activestatus': true
  // };
  constructor(private formBuilder: FormBuilder, private router: Router, private addQueueManagerService: AddQueueManagerService,
    private messageService: MessageService) {

  }

  ngOnInit() {
    this.getQmanagerList();
    this.addQueueForm = this.formBuilder.group({
      // location: ['', Validators.required],
      queuemanagername: ['', Validators.required],
      qmanagerphonenumber: ['', Validators.required],
      qmanageremailId: ['', Validators.required]
      // location: ['', Validators.required]
    });
    this.showLoader = false;
  }

  ngOnDestroy() {
    this.subscriberFlag = false;
  }


  associateLocation() {
    this.router.navigate(['/associate-location-qmanager']);
  }

  showDeleteMessage() {
    this.messageService.add({ sticky: true, severity: 'success', summary: 'Success message', detail: 'Successfully deleted' });
  }
  showEditMessage() {
    this.messageService.add({ sticky: true, severity: 'success', summary: 'Success message', detail: 'Successfully edited location' });
  }

  showAddMessage() {
    this.messageService.add({ sticky: true, severity: 'success', summary: 'Success message', detail: 'Successfully added location' });
  }

  onSubmit() {
    if (this.addQueueForm.valid) {

      for (const key in this.addQueueForm.value) {
        if (this.addQueueForm.value.hasOwnProperty(key)) {
          console.log(key, this.saveLocationRequest[key]);
          if (key === 'vendor') {
            this.saveLocationRequest[key]['vendorid'] = this.addQueueForm.value[key];
          } else {
            this.saveLocationRequest[key] = this.addQueueForm.value[key];
          }
        }
      }
      console.log(this.saveLocationRequest);
      if (this.editFlag) {
        this.saveLocationRequest['queuemanagerid'] = this.queueManagerId;
        this.addQueueManagerService.editQueueManagerDetails(this.queueManagerId, this.saveLocationRequest)
          .subscribe(data => {
            if (data) {
              this.showEditMessage();
              this.getQmanagerList();
              this.showLoader = true;
            }
          });
        this.editFlag = false;
      } else {
        this.addQueueManagerService.createQueueManager(this.saveLocationRequest)
          .subscribe(data => {
            if (data) {
              this.showAddMessage();
              this.getQmanagerList();
            }
          });
      }
      this.addQueueForm.reset();
      this.showLoader = false;
      this.submitted = false;
    } else {
      this.submitted = true;
    }
  }

  resetForm() {
    this.addQueueForm.reset();
  }

  getQmanagerList() {
    this.showLoader = true;
    this.addQueueManagerService.getQueueManagerList(1)
      .pipe(takeWhile(() => this.subscriberFlag))
      .subscribe((response: any) => {
        this.qmanagerList = response;
        this.showLoader = false;
        console.log('vendor list' + response);

      }, (error: HttpErrorResponse) => {
        console.log(error);
      });

  }

  getEditQueueManagerDetail(queueManagerId) {
    console.log(queueManagerId);
    this.editFlag = true;
    this.showLoader = true;
    this.addQueueManagerService.getQueueManagerDetail(1, queueManagerId)
      .pipe(takeWhile(() => this.subscriberFlag))
      .subscribe((response: any) => {
        console.log(response);
        this.queueManagerId = response.queuemanagerid;
        this.patchData(response);
        this.showLoader = false;
      }, (error: HttpErrorResponse) => {
        console.log(error);
      });

  }

  deleteQueueManager(queueManagerId) {
    this.showLoader = true;
    this.addQueueManagerService.deleteLocationDetail(1, queueManagerId)
      .subscribe(data => {
        this.showDeleteMessage();
        this.getQmanagerList();
        this.showLoader = false;
      });
  }

  patchData(response: any) {
    for (const key in this.patchObject) {
      if (this.patchObject.hasOwnProperty(key)) {
        this.addQueueForm.controls[key].setValue(response[key]);
      }
    }
  }
}
