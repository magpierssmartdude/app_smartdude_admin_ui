import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { QueueDetailsComponent } from './queue-details.component';

const routes: Routes = [
    { path: '', component: QueueDetailsComponent }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class CreateAccountRoutingModule { }
