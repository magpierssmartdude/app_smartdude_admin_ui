export interface SignUpDTO {
    vendorcode: string;
    vendorname: string;
    organizationtype: string;
    organizationname: string;
    phonenumber: string;
    status: number;
}
