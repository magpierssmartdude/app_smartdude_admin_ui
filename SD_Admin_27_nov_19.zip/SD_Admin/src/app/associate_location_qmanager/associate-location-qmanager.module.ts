import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { PanelModule } from 'primeng/panel';
import { ReactiveFormsModule } from "@angular/forms";
import {DropdownModule} from 'primeng/dropdown';
import { CardModule } from 'primeng/card';
import { PaginatorModule } from 'primeng/paginator';
import { AssociateLocationQManagerComponent } from './associate-location-qmanager.component';
import { FileUploadModule } from 'primeng/fileupload';

@NgModule({
    imports: [
        CommonModule,
        PanelModule,
        ReactiveFormsModule,
        FileUploadModule,
        CardModule,
        DropdownModule,
        PaginatorModule
    ],
    declarations: [AssociateLocationQManagerComponent],
    providers: [DatePipe]
})

export class AssociateLocationQManagerModule {

    constructor() {
    }

}
