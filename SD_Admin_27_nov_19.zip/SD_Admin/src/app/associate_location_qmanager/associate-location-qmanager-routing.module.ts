import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AssociateLocationQManagerComponent } from './associate-location-qmanager.component';

const routes: Routes = [
    { path: 'add-queue', component: AssociateLocationQManagerComponent }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class AssociateLocationQManagerRoutingModule { }
