import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchQueueComponent } from './search-queue.component';

describe('DashboardComponent', () => {
  let component: SearchQueueComponent;
  let fixture: ComponentFixture<SearchQueueComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SearchQueueComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchQueueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
